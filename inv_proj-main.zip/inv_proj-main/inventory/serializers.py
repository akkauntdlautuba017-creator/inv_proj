from rest_framework import serializers
from inventory import models


class InventorySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Product
        fields = ['id', 'name', 'quantity', 'income_price', 'minimal_price', 'category', 'qty_photos']


class PhotoSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Photo
        fields = ['id', 'description', 'document', 'uploaded_at', 'product_id',]


class ImportproductsSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Import_products
        fields = ['id',
                  'name',
                  'description',
                  'gtd_id',
                  'date',
                  'category',
                  'quantity',
                  "income_quantity",
                  "type",
                  "income_price",
                  "minimal_price"]


class ImportSuppliersSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ImportSuppliers
        fields = ['id', 'name']


class ImportproductsShipmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.import_product_shipment
        fields = ['id', 'reciever', 'date', 'quantity', 'product_id', 'billing_number']


class SearchImportPriceSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.SearchImportPrice
        fields = ['id',
                  'article',
                  'name',
                  'yuan_price',
                  'type',
                  'vehicle',
                  'supplier',
                  'timestamp']


class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Order
        fields = ['id',
                  'article',
                  'name',
                  'quantity',
                  'shipped_quantity',
                  'rub_price',
                  'rub_sum',
                  'type',
                  'vehicle',
                  'order_number']


class ExecuteOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ExecuteOrder
        fields = ['id',
                  'order_id',
                  'article',
                  'name',
                  'quantity',
                  'yuan_price',
                  'yuan_sum',
                  'type',
                  'vehicle',
                  'supplier',
                  'proform',
                  'order_number',
                  'timestamp']


class ShipOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ShipOrder
        fields = ['id',
                  'order_id',
                  'article',
                  'name',
                  'quantity',
                  'yuan_price',
                  'yuan_sum',
                  'type',
                  'vehicle',
                  'supplier',
                  'proform',
                  'invoice',
                  'shipped_quantity',
                  'order_number',
                  'timestamp']


class ProductSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = models.product_arrival
        fields = ['id', 'supplier', 'date', 'quantity', 'name']


class ProductShipment(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = models.product_shipment
        fields = ['id', 'reciever', 'date', 'quantity', 'name']
