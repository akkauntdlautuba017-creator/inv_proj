import logging
from datetime import datetime, timedelta
import pandas as pd
import os
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.shortcuts import render
from django.utils import timezone
from django.db import transaction
from django.views.decorators.csrf import csrf_exempt
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import status
from rest_framework import viewsets, generics, mixins
from rest_framework.decorators import action
from rest_framework.decorators import permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.viewsets import ViewSet
from django.http import FileResponse
from django.core.files.storage import default_storage
from core.shortcuts import get_object_or_404
from inventory.models import (Product,
                              product_arrival,
                              product_shipment,
                              Import_products,
                              import_product_shipment,
                              LastArrival,
                              Order,
                              Photo,
                              ExecuteOrder,
                              ShipOrder,
                              ImportSuppliers,
                              LastShipping,
                              SearchImportPrice
                              )
from inventory.serializers import (ProductSerializer,
                                   ProductShipment,
                                   InventorySerializer,
                                   ImportproductsSerializer,
                                   ImportproductsShipmentSerializer,
                                   OrderSerializer,
                                   ExecuteOrderSerializer,
                                   ShipOrderSerializer,
                                   ImportSuppliersSerializer,
                                   PhotoSerializer,
                                   SearchImportPriceSerializer
                                   )
from .forms import DocumentForm, PhotoForm, ImportPriceForm, SearchPriceForm, FitPriceForm
from .permissions import IsNotManager
from .utils import XLSXSave, ProductSave, OrderSave, ImportPriceSave, SearchPrice

logger = logging.getLogger(__name__)


class InventoryViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = InventorySerializer
    http_method_names = ['get', 'post', 'put']
    filter_backends = [DjangoFilterBackend]

    def list(self, request, *args, **kwargs):
        if request.user.groups.filter(name='managers').exists():
            filterset_fields = ["Резцы", "Резцедержатели", "Ножи", "Базы", "Болты", "Техпластины", "Прочее", "?"]
            queryset = self.filter_queryset(self.get_queryset()).filter(category__in = filterset_fields)
        else:
            filterset_fields = ["Резцы", "Резцедержатели", "Ножи", "Базы", "Болты", "Техпластины", "Прочее",
                                "Примэкс", "?"]
            queryset = self.filter_queryset(self.get_queryset()).filter(category__in = filterset_fields)
        page = self.paginate_queryset(queryset)
        print(request.user)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    def create(self, request, *args, **kwargs):
        if not IsNotManager().has_permission(request, self):
            return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
        print(request.data)
        return super().create(request, *args, **kwargs)

    def create_custom_record(self, request):
        if not IsNotManager().has_permission(request, self):
            return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            # print("POSTED HERE")
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ImportproductsViewSet(viewsets.ModelViewSet):
    queryset = Import_products.objects.all()
    serializer_class = ImportproductsSerializer
    http_method_names = ['get', 'post', 'put', 'delete']

    def list(self, request, *args, **kwargs):
        if not request.user.groups.filter(name='managers').exists():
            queryset = self.filter_queryset(self.get_queryset()).filter()
        else:
            queryset = self.filter_queryset(self.get_queryset()).filter()
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        print(request.user)
        serializer = self.get_serializer(queryset, many=True)
        # print(serializer.data)
        return Response(serializer.data)

    @action(detail=False, methods=['get'], url_path='get_filtered')
    def get_filtered(self, request, *args, **kwargs):
        quantity_param = request.GET.get('quantity', None)
        queryset = self.filter_queryset(self.get_queryset())

        try:
            quantity = int(quantity_param)
            queryset = queryset.filter(quantity__gt=quantity)
        except ValueError:
            return Response({"error": "Invalid quantity parameter"}, status=400)

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    def destroy(self, request, *args, **kwargs):
        return super().destroy(request, *args, **kwargs)

    def update(self, request, *args, **kwargs):
        if not IsNotManager().has_permission(request, self):
            return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)

    def create(self, request, *args, **kwargs):
        if not IsNotManager().has_permission(request, self):
            return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
        return super().create(request, *args, **kwargs)

    @action(detail=False, methods=['get'], url_path='shipments_by_description/(?P<product_id>[^/.]+)')
    def get_shipments_by_description(self, request, product_id=None):
        if not product_id:
            return Response({"detail": "product_id parameter is required."}, status=status.HTTP_400_BAD_REQUEST)

        shipments = import_product_shipment.objects.filter(product_id=product_id)
        serializer = ImportproductsShipmentSerializer(shipments, many=True)
        return Response(serializer.data)

    def create_custom_record(self, request):
        # if not IsNotManager().has_permission(request, self):
        #     return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SearchImportPriceViewSet(viewsets.ModelViewSet):
    queryset = SearchImportPrice.objects.all()
    serializer_class = SearchImportPriceSerializer
    http_method_names = ['get', 'post', 'put', 'delete']

    def list(self, request, *args, **kwargs):
        if not request.user.groups.filter(name='managers').exists():
            queryset = self.filter_queryset(self.get_queryset()).filter()
        else:
            queryset = self.filter_queryset(self.get_queryset()).filter()
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    def destroy(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            print(f"Attempting to delete instance: {instance}")
            self.perform_destroy(instance)
            return Response(status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            # import traceback
            # tb_str = traceback.format_exception(etype=type(e), value=e, tb=e.__traceback__)
            # print(''.join(tb_str))
            return Response({"detail": "Internal Server Error"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def update(self, request, *args, **kwargs):
        if not IsNotManager().has_permission(request, self):
            return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)

    def create(self, request, *args, **kwargs):
        if not IsNotManager().has_permission(request, self):
            return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
        return super().create(request, *args, **kwargs)


class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer
    http_method_names = ['get', 'post', 'put', 'delete']

    def list(self, request, *args, **kwargs):
        if not request.user.groups.filter(name='managers').exists():
            queryset = self.filter_queryset(self.get_queryset()).filter()
        else:
            queryset = self.filter_queryset(self.get_queryset()).filter()
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    def destroy(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            print(f"Attempting to delete instance: {instance}")  # Отладочный вывод
            self.perform_destroy(instance)
            return Response(status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            import traceback
            tb_str = traceback.format_exception(etype=type(e), value=e, tb=e.__traceback__)
            print(''.join(tb_str))
            return Response({"detail": "Internal Server Error"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def update(self, request, *args, **kwargs):
        if not IsNotManager().has_permission(request, self):
            return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)

    def create(self, request, *args, **kwargs):
        if not IsNotManager().has_permission(request, self):
            return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
        return super().create(request, *args, **kwargs)

    # @action(detail=False, methods=['get'], url_path='shipments_by_description/(?P<product_id>[^/.]+)')
    # def get_shipments_by_description(self, request, product_id=None):
    #     if not product_id:
    #         return Response({"detail": "product_id parameter is required."}, status=status.HTTP_400_BAD_REQUEST)
    #
    #     shipments = import_product_shipment.objects.filter(product_id=product_id)
    #     serializer = ImportproductsShipmentSerializer(shipments, many=True)
    #     return Response(serializer.data)
    #
    # def create_custom_record(self, request):
    #     # if not IsNotManager().has_permission(request, self):
    #     #     return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
    #     serializer = self.get_serializer(data=request.data)
    #     if serializer.is_valid():
    #         serializer.save()
    #         return Response(serializer.data, status=status.HTTP_201_CREATED)
    #     else:
    #         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ExecuteOrderViewSet(viewsets.ModelViewSet):
    queryset = ExecuteOrder.objects.all()
    serializer_class = ExecuteOrderSerializer
    http_method_names = ['get', 'post', 'put', 'delete']

    def list(self, request, *args, **kwargs):
        if not request.user.groups.filter(name='managers').exists():
            queryset = self.filter_queryset(self.get_queryset()).filter()
        else:
            queryset = self.filter_queryset(self.get_queryset()).filter()
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        print(request.user)

        serializer = self.get_serializer(queryset, many=True)

        try:
            for item in serializer.data:
                order = Order.objects.get(id=item['order_id'])
                item['init_quantity'] = int(order.quantity)
                item['shipped_quantity'] = int(Order.objects.get(id=item['order_id']).shipped_quantity)
        except:
            for item in serializer.data:
                item['init_quantity'] = -1
                item['shipped_quantity'] = -1
        return Response(serializer.data)

    def destroy(self, request, *args, **kwargs):
        return super().destroy(request, *args, **kwargs)

    def update(self, request, *args, **kwargs):
        if not IsNotManager().has_permission(request, self):
            return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)

    def create(self, request, *args, **kwargs):
        if not IsNotManager().has_permission(request, self):
            return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
        return super().create(request, *args, **kwargs)

    # @action(detail=False, methods=['get'], url_path='shipments_by_description/(?P<product_id>[^/.]+)')
    # def get_shipments_by_description(self, request, product_id=None):
    #     if not product_id:
    #         return Response({"detail": "product_id parameter is required."}, status=status.HTTP_400_BAD_REQUEST)
    #
    #     shipments = import_product_shipment.objects.filter(product_id=product_id)
    #     serializer = ImportproductsShipmentSerializer(shipments, many=True)
    #     return Response(serializer.data)
    #
    # def create_custom_record(self, request):
    #     # if not IsNotManager().has_permission(request, self):
    #     #     return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
    #     serializer = self.get_serializer(data=request.data)
    #     if serializer.is_valid():
    #         serializer.save()
    #         return Response(serializer.data, status=status.HTTP_201_CREATED)
    #     else:
    #         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ShipOrderViewSet(viewsets.ModelViewSet):
    queryset = ShipOrder.objects.all()
    serializer_class = ShipOrderSerializer
    http_method_names = ['get', 'post', 'put', 'delete']

    @transaction.atomic
    def list(self, request, *args, **kwargs):
        if not request.user.groups.filter(name='managers').exists():
            queryset = self.filter_queryset(self.get_queryset()).filter()
        else:
            queryset = self.filter_queryset(self.get_queryset()).filter()
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        print(request.user)
        serializer = self.get_serializer(queryset, many=True)
        print("serializer.data", serializer.data)
        try:
            for item in serializer.data:
                order = Order.objects.get(id=item['order_id'])
                item['init_quantity'] = int(order.quantity)
                item['shipped_quantity'] = int(Order.objects.get(id=item['order_id']).shipped_quantity)
        except:
            for  item in serializer.data:
                item['init_quantity'] = -1
                item['shipped_quantity'] = -1
        return Response(serializer.data)

    def destroy(self, request, *args, **kwargs):
        return super().destroy(request, *args, **kwargs)

    def update(self, request, *args, **kwargs):
        if not IsNotManager().has_permission(request, self):
            return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)

    def create(self, request, *args, **kwargs):
        if not IsNotManager().has_permission(request, self):
            return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
        print("request.data", request.data)
        order = Order.objects.get(id=request.data['order_id'])
        print("ord_sh_qnt before", order.shipped_quantity)
        order.shipped_quantity += int(request.data['shipped_quantity'])
        order.save()
        print("ord_sh_qnt", order.shipped_quantity)
        print("SHIP_ORDER: ", request.data)

        return super().create(request, *args, **kwargs)


@csrf_exempt
@transaction.atomic
def upload_price_file(request):
    print('inside upd')
    if request.method == 'POST':
        form = ImportPriceForm(request.POST, request.FILES, user=request.user)
        if form.is_valid():
            form.save()
            uploaded_file = request.FILES['document']
            data = pd.ExcelFile(uploaded_file)
            print("uploaded_file name: ", uploaded_file)
            sheet_to_df_map = {}
            for sheet_name in data.sheet_names:
                sheet_to_df_map[sheet_name] = data.parse(sheet_name)
                ImportPriceSave.save_data(sheet_to_df_map[sheet_name], str(uploaded_file))
                print(sheet_name, " DONE")
            print(data)
            try:
                return JsonResponse({'success': True})
            except Exception as e:
                return JsonResponse({'success': False, 'errors': str(e)})
        else:
            return JsonResponse({'success': False, 'errors': form.errors})
    else:
        return JsonResponse({'error': 'Метод не разрешен'}, status=405)


@csrf_exempt
@transaction.atomic
def upload_fit_price(request):
    print('inside ufp')
    if request.method == 'POST':
        form = FitPriceForm(request.POST, request.FILES, user=request.user)
        if form.is_valid():
            form.save()
            uploaded_file = request.FILES['document']
            data = pd.ExcelFile(uploaded_file)
            print("uploaded_file name: ", uploaded_file)
            product_ids_raw = request.POST.get('product_id')
            product_ids_list = product_ids_raw.split(',')

            prices = {}
            sheet_to_df_map = {}

            for sheet_name in data.sheet_names:
                sheet_to_df_map[sheet_name] = data.parse(sheet_name)
                sheet_to_df_map[sheet_name][["Артикул", "Название"]] = (
                    sheet_to_df_map[sheet_name][["Артикул", "Название"]].astype(str))

                for idd in product_ids_list:
                    print(idd)
                    product = Order.objects.get(id=int(idd))
                    article = product.article
                    print(article)
                    print(sheet_to_df_map[sheet_name]['Артикул'])
                    founded_row = sheet_to_df_map[sheet_name].loc[sheet_to_df_map[sheet_name]['Артикул'] == article]
                    print("founded_row: ", founded_row)
                    if len(founded_row) > 0:
                        prices[idd] = str(sheet_to_df_map[sheet_name].loc[sheet_to_df_map[sheet_name]['Артикул'] ==
                                                                      article]['Цена'].values[0])
                print(sheet_name, " DONE")
            print("Prices: ", prices)

            try:
                return JsonResponse({'success': True, 'prices': prices})
            except Exception as e:
                return JsonResponse({'success': False, 'errors': str(e)})
        else:
            return JsonResponse({'success': False, 'errors': form.errors})
    else:
        return JsonResponse({'error': 'Метод не разрешен'}, status=405)


@csrf_exempt
@transaction.atomic
def upload_search_file(request):
    print('inside upd')
    if request.method == 'POST':
        form = SearchPriceForm(request.POST, request.FILES, user=request.user)
        if form.is_valid():
            form.save()
            uploaded_file = request.FILES['document']
            data = pd.ExcelFile(uploaded_file)
            sheet_to_df_map = {}

            for sheet_name in data.sheet_names:
                sheet_to_df_map[sheet_name] = data.parse(sheet_name)
                # Обработка данных и сохранение результата
                file_name = SearchPrice.search(sheet_to_df_map[sheet_name], str(uploaded_file))

            # Получаем путь к сохраненному файлу (например, путь в хранилище)
            file_path = default_storage.path(file_name)  # Путь к сохраненному файлу

            # Проверьте, существует ли файл
            if os.path.exists(file_path):
                # Отправляем файл обратно пользователю для скачивания
                try:
                    response = FileResponse(open(file_path, 'rb'), as_attachment=True, filename='edited_22.xlsx')
                    return response
                except Exception as e:
                    return JsonResponse({'success': False, 'errors': str(e)})
            else:
                return JsonResponse({'success': False, 'errors': f"File not found: {file_path}"})
        else:
            return JsonResponse({'success': False, 'errors': form.errors})
    else:
        return JsonResponse({'error': 'Метод не разрешен'}, status=405)


# def upload_search_file(request):
#     print('inside upd')
#     if request.method == 'POST':
#         form = SearchPriceForm(request.POST, request.FILES, user=request.user)
#         if form.is_valid():
#             form.save()
#             uploaded_file = request.FILES['document']
#             data = pd.ExcelFile(uploaded_file)
#             sheet_to_df_map = {}
#             for sheet_name in data.sheet_names:
#                 sheet_to_df_map[sheet_name] = data.parse(sheet_name)
#                 file_name = SearchPrice.search(sheet_to_df_map[sheet_name], str(uploaded_file))
#             # Вывод данных для отладки
#             print(data)
#             try:
#                 return JsonResponse({'success': True, 'data: ': file_name})
#             except Exception as e:
#                 return JsonResponse({'success': False, 'errors': str(e)})
#         else:
#             return JsonResponse({'success': False, 'errors': form.errors})
#     else:
#         return JsonResponse({'error': 'Метод не разрешен'}, status=405)


@csrf_exempt
@transaction.atomic
def upload_file(request):
    print('inside upd')
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES, user=request.user)
        if form.is_valid():
            form.save()
            uploaded_file = request.FILES['document']
            data = pd.read_excel(uploaded_file)

            # # Вывод данных для отладки
            # print('Read data from Excel:')
            # print(data.head())
            try:
                XLSXSave.save_data_with_user(data, request.user)
                return JsonResponse({'success': True})
            except Exception as e:
                return JsonResponse({'success': False, 'errors': str(e)})
        else:
            return JsonResponse({'success': False, 'errors': form.errors})
    else:
        return JsonResponse({'error': 'Метод не разрешен'}, status=405)


class PhotoViewSet(viewsets.ModelViewSet):
    queryset = Photo.objects.all()
    serializer_class = PhotoSerializer
    http_method_names = ['get', 'post', 'put']
    filter_backends = [DjangoFilterBackend]

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset().filter(product_id__exact=request.GET['product_id']))
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


def upload_order(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES, user=request.user)
        if form.is_valid():
            form.save()
            uploaded_file = request.FILES['document']
            data = pd.read_excel(uploaded_file)
            try:
                OrderSave.save_data(data, request.user)
                return JsonResponse({'success': True})
            except Exception as e:
                return JsonResponse({'success': False, 'errors': str(e)})
        else:
            return JsonResponse({'success': False, 'errors': form.errors})
    else:
        return JsonResponse({'error': 'Метод не разрешен'}, status=405)


def upload_data_file(request: object) -> object:
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES, user=request.user)
        if form.is_valid():
            form.save()
            uploaded_file = request.FILES['document']
            data = pd.read_excel(uploaded_file)
            print("data: ", data)

            arrival_names, arrival_quantities = ProductSave.save_data_with_user(data, request.user)
            print(arrival_names, arrival_quantities)
            for name, quantity in zip(arrival_names, arrival_quantities):
                last_arrival, created = LastArrival.objects.update_or_create(
                    product_name=name,
                    defaults={'quantity': quantity}
                    )
            print(last_arrival, created)

            return JsonResponse({'success': True})
        else:
            return JsonResponse({'success': False, 'errors': form.errors})
    else:
        return JsonResponse({'error': 'Метод не разрешен'}, status=405)


def upload_photo(request):
    if request.method == 'POST':
        form = PhotoForm(request.POST, request.FILES, user=request.user)
        if form.is_valid():
            form.save()
            uploaded_file = request.FILES['document']
            product_id = request.POST.get('product_id')
            product = Product.objects.get(id=product_id)
            product.qty_photos += 1
            product.save()
            return JsonResponse({'success': True})
        else:
            return JsonResponse({'success': False, 'errors': form.errors})
    else:
        return JsonResponse({'error': 'Метод не разрешен'}, status=405)


class ImportproductsManagerViewSet(viewsets.ModelViewSet):
    queryset = Import_products.objects.filter(quantity__gt=0)
    serializer_class = ImportproductsSerializer
    http_method_names = ['get', 'post', 'put', 'delete']

    def list(self, request, *args, **kwargs):
        #if not request.user.groups.filter(name='managers').exists():
        queryset = self.filter_queryset(self.get_queryset()).filter()
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        print(request.user)
        return Response(serializer.data)


class ImportSuppliersViewSet(viewsets.ModelViewSet):
    queryset = ImportSuppliers.objects.all()
    serializer_class = ImportSuppliersSerializer
    http_method_names = ['get', 'post', 'put', 'delete']

    def list(self, request, *args, **kwargs):
        if not request.user.groups.filter(name='managers').exists():
            queryset = self.filter_queryset(self.get_queryset()).filter()
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        print(request.user)
        return Response(serializer.data)


class ImportproductsShipmentViewSet(viewsets.ModelViewSet):
    queryset = import_product_shipment.objects.all()
    serializer_class = ImportproductsShipmentSerializer
    http_method_names = ['get', 'post', 'put', 'delete']

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        product = Import_products.objects.get(id=instance.product_id)
        new_quantity = product.quantity + int(instance.quantity)
        product.quantity = new_quantity
        product.save()
        self.perform_destroy(instance)
        return Response(status=status.HTTP_204_NO_CONTENT)

    def perform_destroy(self, instance):
        instance.delete()

    def create(self, request, *args, **kwargs):
        product_id = request.data.get('product_id')
        try:
            product = Import_products.objects.get(id=product_id)
        except Exception as e:
            return Response({"detail": e}, status=status.HTTP_404_NOT_FOUND)

        new_quantity = product.quantity - int(request.data.get('quantity'))
        product.quantity = new_quantity
        product.save()
        shipment = import_product_shipment.objects.create(
            product_id=request.data.get('product_id'),
            date=request.data.get('date'),
            reciever=request.data.get('reciever'),
            quantity=request.data.get('quantity'),
            billing_number=request.data.get('billing_number')
        )
        return Response({"detail": "Shipment created successfully."}, status=status.HTTP_201_CREATED)

    @action(detail=False, methods=['get'], url_path='description/(?P<product_id>[^/.]+)')
    def get_shipments_by_description(self, request, product_id=None):
        if not product_id:
            return Response({"detail": "Description parameter is required."}, status=status.HTTP_400_BAD_REQUEST)

        shipments = import_product_shipment.objects.filter(product_id=product_id)
        serializer = ImportproductsShipmentSerializer(shipments, many=True)
        return Response(serializer.data)


#Продукт
class ProductViewSet(viewsets.ModelViewSet):
    queryset = product_arrival.objects.all()
    serializer_class = ProductSerializer

    def get_object(self):
        queryset = self.get_queryset()
        return get_object_or_404(queryset, pk=self.kwargs[self.lookup_field])

    @permission_classes([IsAuthenticated, IsNotManager])
    def perform_create(self, request):
        pass


class ArrivalMixinView(viewsets.GenericViewSet,
                       generics.ListCreateAPIView,
                       mixins.RetrieveModelMixin):

    queryset = product_arrival.objects.all()
    serializer_class = ProductSerializer

    def get(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)

    def create(self, request, *args, **kwargs):
        if not IsNotManager().has_permission(request, self):
            return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
        return super().create(request, *args, **kwargs)

    def perform_create(self, serializer):
        if serializer.is_valid():
            serializer.save()
        product_name = serializer.validated_data.get("name")
        product_quantity = serializer.validated_data.get("quantity")
        product_category = serializer.validated_data.get("category")
        print(product_name)
        if product_name and product_quantity:
            try:
                product = Product.objects.filter(name=product_name).first()
                print(product)
                product_quantity = int(product_quantity)
                if product:
                    product.quantity += product_quantity
                    product.save()
                    print(product, product.quantity)
                else:
                    new_product_data = {
                        "name": product_name,
                        "quantity": product_quantity,
                        "description": " ",
                        "category": product_category,
                    }
                    inventory_serializer = InventorySerializer(data=new_product_data)
                    if inventory_serializer.is_valid():
                        inventory_serializer.save()
                    else:
                        return Response(inventory_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

                last_arrival, created = LastArrival.objects.update_or_create(
                    product_name=product_name,
                    defaults={'quantity': product_quantity}
                )

                print(last_arrival, created)
            except ValueError:
                return Response({"error": "Invalid quantity value"}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=['GET'])
    def filter_by_dates(self, request):
        start_date = request.GET.get('start_date')
        end_date = request.GET.get('end_date')
        if start_date:
            try:
                if start_date and end_date:
                    start_date = datetime.strptime(start_date, '%Y-%m-%d')
                    end_date = datetime.strptime(end_date, '%Y-%m-%d')
                    user = request.user
                    user_groups = user.groups.values_list('name', flat=True)  # TODO
                    queryset = self.queryset.filter(date__range=[start_date, end_date])
                    serializer = self.serializer_class(queryset, many=True)
                    if serializer.data:
                        return Response(serializer.data)
                    else:
                        return Response({"error": "Неверно указаны даты"}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        else:
            self.get(request)


class LastArrivalViewSet(ViewSet):
    def list(self, request, pk=None):
        try:
            now = timezone.now()
            last_arrivals = LastArrival.objects.filter(
                timestamp__gte=now-timedelta(hours=24)
            )
            if last_arrivals.exists():
                data = [
                    {
                        "name": arrival.product_name,
                        "quantity": arrival.quantity,
                        "date": arrival.timestamp
                    }
                    for arrival in last_arrivals
                ]

                return Response(data, status=status.HTTP_200_OK)
            else:
                return Response({"detail": "No recent arrivals found."}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class LastShippingViewSet(ViewSet):
    def list(self, request, pk=None):
        try:
            now = timezone.now()
            last_shippings = LastShipping.objects.filter(
                timestamp__gte=now-timedelta(hours=24)
            )
            if last_shippings.exists():
                data = [
                    {
                        "name": shipping.product_name,
                        "quantity": shipping.quantity,
                        "date": shipping.timestamp
                    }
                    for shipping in last_shippings
                ]
                return Response(data, status=status.HTTP_200_OK)
            else:
                return Response({"detail": "No recent arrivals found."}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class ShippingMixinView(viewsets.GenericViewSet,
                        generics.ListCreateAPIView,
                        mixins.RetrieveModelMixin):
    queryset = product_shipment.objects.all()
    serializer_class = ProductShipment


    def get(self, request, *args, **kwargs):
        print(args, kwargs)
        return self.list(request, *args, **kwargs)

    def create(self, request, *args, **kwargs):
        if not IsNotManager().has_permission(request, self):
            return Response({"detail": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)
        return super().create(request, *args, **kwargs)

    def perform_create(self, serializer):
        if serializer.is_valid():
            serializer.save()
        product_name = serializer.validated_data.get("name")
        product_quantity = serializer.validated_data.get("quantity")

        if product_name and product_quantity:
            try:
                product_quantity = int(product_quantity)
                print('minus ', product_quantity)
                product = Product.objects.filter(name=product_name).first()
                if product:
                    product.quantity -= product_quantity
                    print(product.quantity)
                    print(product)
                    product.save()
                    last_shipping, created = LastShipping.objects.update_or_create(
                        product_name=product_name,
                        defaults={'quantity': product_quantity}
                    )
                    print(last_shipping, created)
                    return Response({"ok": "Invalid quantity value"}, status=status.HTTP_200_OK)

            except ValueError:
                return Response({"error": "Invalid quantity value"}, status=status.HTTP_400_BAD_REQUEST)


def arrival(request):
    user_is_manager = request.user.groups.filter(name='managers').exists()
    return render(request, 'inventory/index_arrival.html', {'user_is_manager': user_is_manager})


def search_import_price(request):
    user_is_manager = request.user.groups.filter(name='managers').exists()
    return render(request, 'inventory/search_import_price.html', {'user_is_manager': user_is_manager})


def proforms(request):
    user_is_manager = request.user.groups.filter(name='managers').exists()
    return render(request, 'inventory/proforms.html', {'user_is_manager': user_is_manager})


def execute_order(request):
    user_is_manager = request.user.groups.filter(name='managers').exists()
    return render(request, 'inventory/execute_order.html', {'user_is_manager': user_is_manager})


def ship_order(request):
    user_is_manager = request.user.groups.filter(name='managers').exists()
    return render(request, 'inventory/ship_order.html', {'user_is_manager': user_is_manager})


def import_products(request):
    user_is_manager = request.user.groups.filter(name='managers').exists()
    if user_is_manager:
        return render(request, 'inventory/import_products_managers.html', {'user_is_manager': user_is_manager})

    else:
        return render(request, 'inventory/import_products.html', {'user_is_manager': user_is_manager})


def import_products_managers(request):
    user_is_manager = request.user.groups.filter(name='managers').exists()
    return (
        render(request, 'inventory/import_products_managers.html', {'user_is_manager': user_is_manager}))


def index(request):
    user_is_manager = request.user.groups.filter(name='managers').exists()
    return render(request, 'inventory/index.html', {'user_is_manager': user_is_manager})


def product_detail(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    return render(request, 'inventory/product_detail.html', {'product': product})


