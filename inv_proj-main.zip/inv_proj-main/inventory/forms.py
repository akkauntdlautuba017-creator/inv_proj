from django import forms
from .models import Document, Photo, FitPrice


class DocumentForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super(DocumentForm, self).__init__(*args, **kwargs)

    def save(self, commit=True):
        instance = super(DocumentForm, self).save(commit=False)
        if self.user:
            instance.description = self.user.username
        if commit:
            instance.save()
        return instance

    class Meta:
        model = Document
        fields = ('description', 'document',)
        widgets = {
            'description': forms.TextInput(attrs={'readonly': 'readonly'}),
            'document': forms.ClearableFileInput(attrs={'class': 'custom-file-input', 'id': 'customFile'}),
            }


class ImportPriceForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super(ImportPriceForm, self).__init__(*args, **kwargs)

    def save(self, commit=True):
        instance = super(ImportPriceForm, self).save(commit=False)
        if self.user:
            instance.description = self.user.username
        if commit:
            instance.save()
        return instance

    class Meta:
        model = Document
        fields = ('description', 'document',)
        widgets = {
            'description': forms.TextInput(attrs={'readonly': 'readonly'}),
            'document': forms.ClearableFileInput(attrs={'class': 'custom-file-input', 'id': 'customFile'}),
            }


class FitPriceForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super(FitPriceForm, self).__init__(*args, **kwargs)

    def save(self, commit=True):
        instance = super(FitPriceForm, self).save(commit=False)
        if self.user:
            instance.description = self.user.username
        if commit:
            instance.save()
        return instance

    class Meta:
        model = FitPrice
        fields = ('description', 'document', 'product_id',)
        widgets = {
            'description': forms.TextInput(attrs={'readonly': 'readonly'}),
            'document': forms.ClearableFileInput(attrs={'class': 'custom-file-input', 'id': 'customFile'}),
            'product_id': forms.Textarea(attrs={'readonly': 'readonly'}),
        }


class SearchPriceForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super(SearchPriceForm, self).__init__(*args, **kwargs)

    def save(self, commit=True):
        instance = super(SearchPriceForm, self).save(commit=False)
        if self.user:
            instance.description = self.user.username
        if commit:
            instance.save()
        return instance

    class Meta:
        model = Document
        fields = ('description', 'document',)
        widgets = {
            'description': forms.TextInput(attrs={'readonly': 'readonly'}),
            'document': forms.ClearableFileInput(attrs={'class': 'custom-file-input', 'id': 'customFile'}),
            }


class PhotoForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super(PhotoForm, self).__init__(*args, **kwargs)

    def save(self, commit=True):
        instance = super(PhotoForm, self).save(commit=False)
        print("instance: ", instance)
        if self.user:
            instance.description = self.user.username
        if commit:
            instance.save()
        return instance

    class Meta:
        model = Photo
        fields = ('description', 'document', 'product_id',)
        print("product_id: ", forms.TextInput(attrs={'readonly': 'readonly'}))
        widgets = {
            'description': forms.TextInput(attrs={'readonly': 'readonly'}),
            'document': forms.ClearableFileInput(attrs={'class': 'custom-file-input', 'id': 'customFile'}),
            'product_id': forms.TextInput(attrs={'readonly': 'readonly'}),
            }
