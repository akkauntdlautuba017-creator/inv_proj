import datetime
from datetime import datetime as dt
from django.db import models
from django.utils import timezone

class Product(models.Model):
    name = models.CharField(max_length=100)
    income_price = models.CharField(default=0)
    minimal_price = models.CharField(default=0)
    category = models.CharField(max_length=100, default='Резцы')
    quantity = models.IntegerField(default=0)
    qty_photos = models.IntegerField(default=0)

    def __str__(self) -> str:
        return self.name

    class Meta:
        ordering = ['-name']

    def get_queryset(self, request):
        if not request.user.IsNotManager():
            qs = super(Product, self).get_queryset(request)
            print(qs)
            filtered_qs = qs.filter(category="Резцы")
            print(filtered_qs)
            return filtered_qs
        else:
            qs = super(Product, self).get_queryset(request)
            print("qs: ", qs)
            return qs


class Import_products(models.Model):
    name = models.CharField(max_length=400)
    description = models.TextField(blank=True)
    gtd_id = models.CharField(max_length=100)
    date = models.DateField(blank=False)
    category = models.CharField(max_length=100)
    quantity = models.IntegerField(default=0)
    income_quantity = models.IntegerField(default=0)
    type = models.CharField(max_length=100, default='')
    income_price = models.CharField(max_length=100, default=0)
    minimal_price = models.CharField(max_length=100, default=0)

    def __str__(self) -> str:
        return self.name

    class Meta:
        ordering = ['-name']


class ImportSuppliers(models.Model):
    name = models.CharField(max_length=400)

    def __str__(self) -> str:
        return self.name


class import_product_shipment(models.Model):
    reciever = models.CharField(max_length=100)
    date = models.DateField(blank=False)
    quantity = models.IntegerField(default=0)
    product_id = models.CharField(max_length=100)
    billing_number = models.IntegerField(default=0)

    def __str__(self) -> str:
        return self.product_id


class product_arrival(models.Model):
    supplier = models.CharField(max_length=100)
    date = models.DateField(blank=True)
    quantity = models.IntegerField(default=0)
    name = models.CharField(max_length=100)

    def __str__(self) -> str:
        return self.name


class product_shipment(models.Model):
    reciever = models.CharField(max_length=100)
    date = models.DateField(blank=True)
    quantity = models.IntegerField(default=0)
    name = models.CharField(max_length=100)

    def __str__(self) -> str:
        return self.name


class Document(models.Model):
    description = models.CharField(max_length=255, blank=True)
    document = models.FileField(upload_to='documents/')
    uploaded_at = models.DateTimeField(auto_now_add=True)


class FitPrice(models.Model):
    description = models.CharField(max_length=255, blank=True)
    document = models.FileField(upload_to='fitprice/')
    product_id = models.CharField(max_length=255, default=0)
    uploaded_at = models.DateTimeField(auto_now_add=True)


class Photo(models.Model):
    description = models.CharField(max_length=255, blank=True)
    document = models.FileField(upload_to='photos/')
    product_id = models.CharField(max_length=255, default=0)
    uploaded_at = models.DateTimeField(auto_now_add=True)


class LastArrival(models.Model):
    product_name = models.CharField(max_length=100)
    quantity = models.IntegerField(default=0)
    timestamp = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.product_name} - {self.quantity}"


class LastShipping(models.Model):
    product_name = models.CharField(max_length=100)
    quantity = models.IntegerField(default=0)
    timestamp = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.product_name} - {self.quantity}"


class SearchImportPrice(models.Model):
    article = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    yuan_price = models.CharField(max_length=100)
    type = models.CharField(max_length=100)
    vehicle = models.CharField(max_length=100)
    supplier = models.CharField(max_length=100)
    timestamp = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class Order(models.Model):
    article = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    quantity = models.IntegerField(default=0)
    shipped_quantity = models.IntegerField(default=0)
    rub_price = models.CharField(max_length=100)
    rub_sum = models.CharField(max_length=100)
    type = models.CharField(max_length=100)
    vehicle = models.CharField(max_length=100)
    order_number = models.PositiveIntegerField(editable=False)

    def save(self, *args, **kwargs):
        if not self.order_number:
            last_order = Order.objects.all().order_by('order_number').last()
            if last_order:
                self.order_number = last_order.order_number + 1
            else:
                self.order_number = 1
        super(Order, self).save(*args, **kwargs)


class ExecuteOrder(models.Model):
    order_id = models.ForeignKey(Order, on_delete=models.CASCADE)
    article = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    quantity = models.IntegerField(default=0)
    yuan_price = models.CharField(max_length=100)
    yuan_sum = models.CharField(max_length=100)
    type = models.CharField(max_length=100)
    vehicle = models.CharField(max_length=100)
    supplier = models.CharField(max_length=100)
    proform = models.CharField(max_length=100)
    order_number = models.IntegerField()
    timestamp = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class ShipOrder(models.Model):
    order_id = models.ForeignKey(Order, on_delete=models.CASCADE)
    article = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    quantity = models.IntegerField(default=0)
    yuan_price = models.CharField(max_length=100)
    yuan_sum = models.CharField(max_length=100)
    type = models.CharField(max_length=100)
    vehicle = models.CharField(max_length=100)
    supplier = models.CharField(max_length=100)
    proform = models.CharField(max_length=100)
    invoice = models.CharField(max_length=100)
    shipped_quantity = models.IntegerField()
    order_number = models.IntegerField()
    timestamp = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name
