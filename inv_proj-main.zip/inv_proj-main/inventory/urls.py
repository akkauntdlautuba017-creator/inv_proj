from django.urls import include, path

from core.router import CustomDefaultRouter
from . import views

router = CustomDefaultRouter(base_prefix="inventorys")
router_ = CustomDefaultRouter(base_prefix="arrival")
router__ = CustomDefaultRouter(base_prefix="shipping")
router___ = CustomDefaultRouter(base_prefix="import_products")
router____ = CustomDefaultRouter(base_prefix="import_products_shipment")
router_____ = CustomDefaultRouter(base_prefix="import_products_managers")
router______ = CustomDefaultRouter(base_prefix="last_arrival")
last_shipping = CustomDefaultRouter(base_prefix="last_shipping")
order_router = CustomDefaultRouter(base_prefix="order")
search_import_price_router = CustomDefaultRouter(base_prefix="search_import_price")
execute_order_router = CustomDefaultRouter(base_prefix="execute_order")
ship_order_router = CustomDefaultRouter(base_prefix="ship_order")
import_suppliers_router = CustomDefaultRouter(base_prefix="import_suppliers")
photo_router = CustomDefaultRouter(base_prefix="photo")

router.register(
    "",
    views.InventoryViewSet,
    basename="inventory",
)
router.register(
    "products",
    views.ProductViewSet,
    basename="products",
)

router___.register(
    "",
    views.ImportproductsViewSet,
    basename="import_products",
)

router_____.register(
    "",
    views.ImportproductsManagerViewSet,
    basename="import_products_managers",
)

router____.register(
    "",
    views.ImportproductsShipmentViewSet,
    basename="import_products_shipment",
)

router_.register(
    "",
    views.ArrivalMixinView,
    basename="arrival",
)
router__.register(
    "",
    views.ShippingMixinView,
    basename="shipping",
)

router______.register(
    "",
    views.LastArrivalViewSet,
    basename="last_arrival",
)

last_shipping.register(
    "",
    views.LastShippingViewSet,
    basename="last_shipping",
)

order_router.register(
    "",
    views.OrderViewSet,
    basename="order",
)

search_import_price_router.register(
    "",
    views.SearchImportPriceViewSet,
    basename="search_import_price",
)

execute_order_router.register(
    "",
    views.ExecuteOrderViewSet,
    basename="execute_order",
)

ship_order_router.register(
    "",
    views.ShipOrderViewSet,
    basename="ship_order",
)

import_suppliers_router.register(
    "",
    views.ImportSuppliersViewSet,
    basename="import_suppliers",
)

photo_router.register(
    "",
    views.PhotoViewSet,
    basename="photo",
)

urlpatterns = [
    path("", include(router.urls)),
    path("", include(router_.urls)),
    path("", include(router__.urls)),
    path("", include(router___.urls)),
    path("", include(router____.urls)),
    path("", include(router_____.urls)),
    path("", include(router______.urls)),
    path("", include(last_shipping.urls)),
    path("", include(search_import_price_router.urls)),
    path("", include(order_router.urls)),
    path("", include(execute_order_router.urls)),
    path("", include(ship_order_router.urls)),
    path("", include(import_suppliers_router.urls)),
    path("", include(photo_router.urls)),
]
