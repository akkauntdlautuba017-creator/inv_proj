import pandas_schema as pds
from sqlalchemy import create_engine
from pandas_schema import Column
from enum import Enum
import psycopg2
import pandas as pd
from django.core.files.storage import default_storage
from inventory.forms import ImportPriceForm
from inventory.models import Order, SearchImportPrice
import re
from datetime import datetime
import copy
from pandas_schema.validation import (LeadingWhitespaceValidation,
                                      TrailingWhitespaceValidation,
                                      CanConvertValidation,
                                      MatchesPatternValidation,
                                      InRangeValidation,
                                      InListValidation)


class XLSXFileEnum(Enum):
    name = 'Наименование'
    article = 'Артикул'
    quantity = 'Количество'
    gtd = 'ГТД'


class FitPriceEnum(Enum):
    article = 'Артикул'
    name = 'Название'
    quantity = 'К-во'
    price = 'Цена'
    type = 'Тип'


class SearchPriceEnum(Enum):
    article = 'Part Number       配件号'
    name = 'Name                                                                 产品名称'
    yuan_price = 'Price, CNY 人民币 单价    含税  '
    type = 'Original   原厂   副厂'
    vehicle = 'Machine '


class SearchEnum(Enum):
    article = 'Part Number       配件号'
    name = 'Name                                                                 产品名称'
    yuan_price = 'Price, CNY 人民币 单价    含税  '
    supplier = 'Supplier'


class ProductFileEnum(Enum):
    name = 'forma'
    category = 'marka'
    quantity = 'kol'


class OrderFileEnum(Enum):
    num = '№'
    article = 'Артикул'
    name = 'Название'
    quantity = 'Количество'
    rub_price = 'Цена за шт, руб'
    rub_sum = 'Сумма, руб'
    type = 'Оригинал'
    vehicle = 'Машина'


class XLSXSave:
    schema = pds.Schema([
        Column(XLSXFileEnum.name.value, [LeadingWhitespaceValidation()]),
        Column(XLSXFileEnum.article.value, [LeadingWhitespaceValidation()]),
        Column(XLSXFileEnum.quantity.value, [InRangeValidation(0, 10000000)]),
        Column(XLSXFileEnum.gtd.value, [LeadingWhitespaceValidation()])
    ])

    @staticmethod
    def get_date(gtd):
        date = re.split('/', gtd)[1]
        return datetime.strptime(date, "%d%m%y")

    @staticmethod
    def validate_data(data):
        errors = XLSXSave.schema.validate(data)
        errors_text = [str(error) for error in errors]
        if errors_text:
            print(errors_text)
            raise Exception('\n'.join(errors_text))

    @staticmethod
    def save_data_with_user(data, user):
        XLSXSave.validate_data(data)

        db_user = 'postgres'
        db_password = 'xXpyYlwhzsPiMvWuttoEdCCsVGFnXdxI'
        db_host = 'nozomi.proxy.rlwy.net'
        db_port = '26904'
        db_name = 'railway'

        db_url = f"postgresql+psycopg2://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"

        data['date'] = data['ГТД'].apply(XLSXSave.get_date)
        data['category'] = ["Категория?" for _ in data['date']]
        data['income_quantity'] = copy.deepcopy(data['Количество'])
        data['income_price'] = [0 for x in data['date']]
        data['minimal_price'] = [0 for x in data['date']]

        data = data.rename(
            columns={'Наименование': 'name', 'Артикул': 'description', 'Количество': 'quantity', 'ГТД': 'gtd_id'}
        )
        print("DATA: ", data)
        engine = create_engine(db_url)
        try:
            data.to_sql('inventory_import_products', engine, if_exists='append', index=False)
        except Exception as e:
            print(e)
            raise e


class ImportPriceSave:
    schema = pds.Schema([
        Column(SearchPriceEnum.article.value, ),
        Column(SearchPriceEnum.name.value, ),
        Column(SearchPriceEnum.yuan_price.value, ),
        Column(SearchPriceEnum.type.value, ),
        Column(SearchPriceEnum.vehicle.value, )
    ])

    @staticmethod
    def validate_data(data):
        errors = ImportPriceSave.schema.validate(data, columns=ImportPriceSave.schema.get_column_names())
        errors_text = [str(error) for error in errors]
        if errors_text:
            print(errors_text)
            raise Exception('\n'.join(errors_text))

    @staticmethod
    def save_data(data, file_name):
        ImportPriceSave.validate_data(data)

        # Удаление первой колонки и переименование оставшихся
        data.drop(data.columns[0], axis=1, inplace=True)
        data = data.rename(
            columns={
                SearchPriceEnum.article.value: 'article',
                SearchPriceEnum.name.value: 'name',
                SearchPriceEnum.yuan_price.value: 'yuan_price',
                SearchPriceEnum.type.value: 'type',
                SearchPriceEnum.vehicle.value: 'vehicle'
            }
        )

        # Извлечение имени поставщика из имени файла
        supplier_name = ''.join([file_name.split(' ')[-1][0].upper(), file_name.split(' ')[-1][1:]])
        supplier_name = supplier_name.split('.')[0]

        print("FINAL DATA: ", data)

        for index, row in data.iterrows():
            try:
                # Приведение типа для поля article
                article = int(row['article'])
                type_lower = str(row['type']).lower()

                # Проверка существующей записи
                existing_record = SearchImportPrice.objects.filter(
                    supplier=supplier_name,
                    article=article,
                    type=type_lower
                ).first()

                if existing_record:
                    # Если запись существует, пропускаем
                    print(f"Запись уже существует: {existing_record}")
                    continue

                # Создаем новую запись
                new_item = SearchImportPrice.objects.create(
                    supplier=supplier_name,
                    article=article,
                    name=row['name'],
                    yuan_price=row['yuan_price'],
                    type=type_lower,
                    vehicle=row['vehicle']
                )
                print(f"Создана новая запись: {new_item}")
            except Exception as e:
                print(f"Ошибка при обработке строки {index}: {e}")
                continue


class SearchPrice:
    @staticmethod
    def search(data, file_name):
        data.drop(data.columns[0], axis=1, inplace=True)

        #print("Data before processing: ", data)
        data[SearchEnum.yuan_price.value] = pd.Series()
        data[SearchEnum.name.value] = pd.Series()
        data[SearchEnum.supplier.value] = pd.Series()

        new_data = []
        supplier_columns = {}

        for index, row in data.iterrows():
            article = row[SearchEnum.article.value]

            records = SearchImportPrice.objects.filter(article=article)

            if records.exists():
                # Создаем словарь для текущего артикула
                article_data = {
                    SearchEnum.article.value: article,
                    SearchEnum.name.value: records.first().name
                }

                for record in records:
                    # Формируем уникальные ключи для типа и цены
                    type_key1 = f"{record.supplier}_оригинал"
                    type_key2 = f"{record.supplier}_аналог"
                    price_key1 = f"{record.supplier}_оригинал"
                    price_key2 = f"{record.supplier}_аналог"

                    # Добавляем значения в словарь
                    if record.type == 'оригинал':
                        article_data[type_key1] = record.type
                        article_data[price_key1] = record.yuan_price
                    else:
                        article_data[type_key2] = record.type
                        article_data[price_key2] = record.yuan_price


                    # Обновляем список колонок поставщиков для сохранения структуры
                    # if record.supplier not in supplier_columns:
                    #     supplier_columns[record.supplier] = []

                print("ARTICLE DATA: ", article_data)
                new_data.append(article_data)

                # Завершаем обработку артикула
                continue

            # Если записей нет, добавляем пустой шаблон
            new_data.append({
                SearchEnum.article.value: article,
                SearchEnum.name.value: None,
                **{x: None for x in supplier_columns}
            })



            # try:
            #     #print("INSIDE FOR: ", index, SearchImportPrice.objects.filter(article=row[SearchEnum.article.value]).yuan_price)
            #     data.at[index, SearchEnum.yuan_price.value] = (
            #         SearchImportPrice.objects.all()(article=row[SearchEnum.article.value]).yuan_price
            #     )
            #     data.at[index, SearchEnum.name.value] = (
            #         SearchImportPrice.objects.all()(article=row[SearchEnum.article.value]).name
            #     )
            #     data.at[index, SearchEnum.supplier.value] = (
            #         SearchImportPrice.objects.all()(article=row[SearchEnum.article.value]).supplier
            #     )
            # except Exception as e:
            #     print(index, e)
            #     continue

        print("Data after processing: ", data)
        new_df = pd.DataFrame(new_data)
        #new_df = new_df.drop_duplicates(subset=SearchEnum.article.value, keep='first')
        data = new_df.copy()
        print(data)
        if data.empty:
            print("DataFrame is empty after processing. Nothing to save.")
            return

        file_name = '1.xlsx'
        try:
            data.to_excel(file_name, index=False)
            print(f"File {file_name} successfully created.")
        except Exception as e:
            print(f"Error while saving Excel file: {e}")
            return

        # Открываем Excel файл как бинарный поток
        try:
            with open(file_name, 'rb') as f:
                # Сохраняем файл через Django storage
                saved_file_name = default_storage.save('edited/1.xlsx', f)
                print(f"File saved with name: {saved_file_name}")
        except Exception as e:
            print(f"Error while reading Excel file: {e}")

        file_path = default_storage.path(saved_file_name)  # Получаем полный путь к файлу
        print("file_path: ", file_path)
        return file_path


class OrderSave:
    schema = pds.Schema([
        Column(OrderFileEnum.num.value, [InRangeValidation(0, 10000000)]),
        Column(OrderFileEnum.article.value, [LeadingWhitespaceValidation()]),
        Column(OrderFileEnum.name.value, [LeadingWhitespaceValidation()]),
        Column(OrderFileEnum.quantity.value, [InRangeValidation(0, 10000000)]),
        Column(OrderFileEnum.rub_price.value, [LeadingWhitespaceValidation()]),
        Column(OrderFileEnum.rub_sum.value, [LeadingWhitespaceValidation()]),
        Column(OrderFileEnum.type.value, [LeadingWhitespaceValidation()]),
        Column(OrderFileEnum.vehicle.value, [LeadingWhitespaceValidation()])
    ])

    @staticmethod
    def validate_data(data):
        errors = OrderSave.schema.validate(data)
        errors_text = [str(error) for error in errors]
        if errors_text:
            print(errors_text)
            raise Exception('\n'.join(errors_text))

    @staticmethod
    def save_data(data, user):
        OrderSave.validate_data(data)

        # Get the next order number
        last_order = Order.objects.all().order_by('order_number').last()
        if last_order:
            next_order_number = last_order.order_number + 1
        else:
            next_order_number = 1

        data.drop(data.columns[0], axis=1, inplace=True)

        data = data.rename(
            columns={
                'Название': 'name',
                'Артикул': 'article',
                'Количество': 'quantity',
                'Цена за шт, руб': 'rub_price',
                'Сумма, руб': 'rub_sum',
                'Оригинал': 'type',
                'Машина': 'vehicle'
            }
        )

        for index, row in data.iterrows():
            Order.objects.create(
                article=row['article'],
                name=row['name'],
                quantity=row['quantity'],
                rub_price=row['rub_price'],
                rub_sum=row['rub_sum'],
                type=row['type'],
                vehicle=row['vehicle'],
                order_number=next_order_number
            )


class ProductSave:
    schema = pds.Schema([
        Column(ProductFileEnum.name.value, [LeadingWhitespaceValidation()]),
        Column(ProductFileEnum.category.value, [LeadingWhitespaceValidation()]),
        Column(ProductFileEnum.quantity.value, [InRangeValidation(0, 10000000)]),
    ])

    def validate_data(data):
        errors = ProductSave.schema.validate(data[[ProductFileEnum.name.value,
                                                   ProductFileEnum.category.value,
                                                   ProductFileEnum.quantity.value,
                                                   ]])
        errors_text = [str(error) for error in errors]
        print(errors_text)
        if errors_text:
            print('\n'.join(errors_text))
            raise Exception('\n'.join(errors_text))
        return data[[ProductFileEnum.name.value,
                     ProductFileEnum.category.value,
                     ProductFileEnum.quantity.value,
                     ]]

    def save_data_with_user(data, user):
        primex = False
        if 8209008000 in data['tnved_for_prn'].to_list():
            primex = True
        data = ProductSave.validate_data(data)
        url = '/api/arrival/'
        print("data: ", data)
        data['name'] = data['marka'] + " " + data['forma']

        connection = psycopg2.connect(
            dbname='railway',
            user='postgres',
            password='xXpyYlwhzsPiMvWuttoEdCCsVGFnXdxI',
            host='nozomi.proxy.rlwy.net',
            port='26904',
            options="-c client_encoding=UTF8"
        )
        arrival_names = []
        arrival_quantities = []
        with connection.cursor() as cursor:
            for item in data[pd.notna(data['marka'])].iloc:
                try:
                    cursor.execute("select name, quantity, category from inventory_product where name = %s ",
                                   (item['name'] if primex else item['forma'],))
                    result = cursor.fetchall()
                    print("FOUND: ", result)
                    if result:
                        category = result[0][2]
                        print("CATEGORY: ", category)
                        print(type(result[0][0]))
                        cursor.execute('UPDATE inventory_product SET quantity = %s WHERE name = %s',
                                       (int(result[0][1] + item['kol']),
                                        item['name'] if primex else item['forma']))
                    else:
                        category = '?'
                        cursor.execute("""
                            INSERT INTO inventory_product (name, quantity, category, qty_photos)
                            VALUES (%s, %s, %s, %s)
                        """, (
                        item['name'] if primex else item['forma'], int(item['kol']), 'Примэкс' if primex else category,
                        0))
                    print('quantity set: ', int(result[0][1] + item['kol']))

                except Exception as e:
                    print(e)
                arrival_names.append(item['forma'])
                arrival_quantities.append(item['kol'])
        connection.commit()
        return arrival_names, arrival_quantities
