"""
URL configuration for inventory_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from inventory import views
from django.conf.urls.static import static
from django.conf import settings
from django.contrib.auth import views as auth_views

from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.urls import include, path

urlpatterns = ([
                   path("admin/", admin.site.urls),
                   path("", views.index),
                   path("index_arrival/", views.arrival),
                   path("import_products/", views.import_products, name='import_products'),
                   path("import_products_managers/", views.import_products_managers, name='import_products_managers'),
                   path("search_import_price/", views.search_import_price, name='search_import_price'),
                   path("proforms/", views.proforms, name='proforms'),
                   path("execute_order/", views.execute_order, name='execute_order'),
                   path("ship_order/", views.ship_order, name='ship_order'),
                   path("api/", include("inventory.urls"), name="inventory"),
                   path('accounts/', include('django.contrib.auth.urls')),
                   path('logout/', auth_views.LogoutView.as_view(), name='logout'),
                   path('upload_file/', views.upload_file, name='upload_file'),
                   path('upload_data_file/', views.upload_data_file, name='upload_data_file'),
                   path('upload_price_file/', views.upload_price_file, name='upload_price_file'),
                   path('upload_fit_price/', views.upload_fit_price, name='upload_fit_price'),
                   path('upload_search_file/', views.upload_search_file, name='upload_search_file'),
                   path('upload_order/', views.upload_order, name='upload_order'),
                   path('upload_photo/', views.upload_photo, name='upload_photo'),

               ] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
               + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
               )
